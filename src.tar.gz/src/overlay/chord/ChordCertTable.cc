#include <cfloat>

#include "hashWatch.h"

#include "Chord.h"
//#include "ChordSuccessorList.h"
//#include "ChordFingerTable.h"
#include "ChordCertTable.h"

#include <iostream>
#include <fstream>

namespace oversim {

using namespace std;



Define_Module(ChordCertTable);

void ChordCertTable::initialize(int stage)
{
    // because of IPAddressResolver, we need to wait until interfaces
    // are registered, address auto-assignment takes place etc.
    if(stage != MIN_STAGE_OVERLAY)
        return;

    maxSize = 1;

    WATCH_DEQUE(certTable);
}

/*void ChordCertTable::setCert(const NodeHandle& node)
{
    //uint32_t p = maxSize - pos - 1;
    NodeHandle thisNode = node;
    publickey = (char *)"M";
    string nodeIp = thisNode.getIp().str();
    string pkIp = string(publickey) + string(nodeIp);
    string certIp = string(cert) + string(nodeIp) + "|";
    OverlayKey somaKey(OverlayKey::sha1(pkIp));

    certTable.push_back(CertEntry(nodeIp, somaKey));
    cout << "The node with IP " << nodeIp << " has a SomaKey with value: " << somaKey << endl;

    //cout << maxSize << endl;
    //certTable[159] = CertEntry(nodeIp, pkIp);
    //certTable[159].first = nodeIp;
}*/


void ChordCertTable::handleMessage(cMessage* msg)
{
    cout << "handles msg" << endl;
    //double d = msg->
    ////////////////////string Ip = msg->getIp();
    /////////////////////////cout << Ip << " Time after cert signing: " << simTime() << endl;/////////////////////////////
    //cout << " Time after cert signing: " << simTime() << endl;
}

void ChordCertTable::initializeCertTable(uint32_t size, const NodeHandle& owner, Chord* overlay)
{
    Enter_Method("initializeCertTable");
    maxSize = size;
    NodeHandle thisNode = owner;
    this->overlay = overlay;
    certTable.clear();
    //uint32_t p = 0;

    publickey = (char *)"random_key";
    cert = (char *)"M==";

    string nodeIp = thisNode.getIp().str();
    string pkIp = string(publickey) + string(nodeIp);
    //string certIp = string(cert) + string(nodeIp) + "|";

    OverlayKey somaKey(OverlayKey::sha1(pkIp));

    certTable.push_back(CertEntry(nodeIp, somaKey));

    //overMessage *somakeyput_msg = new overMessage("overMessage");
    //somakeyput_msg = new overMessage();
    //somakeyput_msg->setDela(certSignDelay);


    //somakeyput_msg->setIp(nodeIp);//////////////////////////////////////////////////
    //scheduleAt(simTime() + certSignDelay, somakeyput_msg);

    simtime_t t_bef_join = simTime() + 0;
    double certSignDelay = 0.005;//send to introducer, sign it and send it back to this node
    simtime_t t_aft_certSign = t_bef_join + certSignDelay;
    //double t_aft_join = (t_aft_certSign + t_aft_fingInsert) - t_bef_join


    //cout << "The node with IP " << nodeIp << " has a cert sign delay of " << t_aft_certSign - t_bef_join << endl;//=====>TO PRINT CERT SIGN DELAY <===========>TO PRINT CERT SIGN DELAY <===========>TO PRINT CERT SIGN DELAY <======

    //cout << "Time after cert signing: " << simTime() << endl;


    //-------------------cout << "The node with IP " << nodeIp << " has a SomaKey with value: " << certTable[0].second << endl;//=====>TO READ CERT VALUE <===========>TO READ CERT VALUE <===========>TO READ CERT VALUE <====
    std::ofstream outFile;
    //outFile.open("/home/omnet12/sim/OverSim/simulations/results/ip-key.txt", std::ios_base::app);
    //outFile << "nodeIp: " << thisNode.getIp() << " - SomaKey: " << certTable[0].second << "\n" << std::flush;
    //cout << "The node with IP " << certTable[0].first << " has a SomaKey with value: " << certTable[0].second << endl << endl;

    //cout << certTable[0] << endl;//

    //cout << certTable.size() << endl;
    //cout << "Inserted" << endl;

    //certTable->setCert(owner);

    //cout << "8" << endl;
    //cout << maxSize << endl;
    //string test[2] = certTable[0];
    //certTable[0].first = 'test';

    //std::cout << certTable[0].first << '\n';

    //printArray(certTable,160);
    //certTable[0] = "test";
    //certTable[0].second.insert(std::make_pair(rtt, node));
    //certTable[0].first = nodeIp;
    //certTable[p] = pkIp;
    //certTable[p] = std::make_pair(std::string(nodeIp), std::string("lightbulbs"));
    //certTable[159] = CertEntry(nodeIp, somaKey);
    //certTable[0] = CertEntry(nodeIp, pkIp);
    //certTable[p].second.insert(std::make_pair(nodeIp, pkIp));
}

uint32_t ChordCertTable::getSize()
{
    return maxSize;
}

};

using namespace oversim;

std::ostream& operator<<(std::ostream& os, const CertEntry& C_entry)
{

    os << C_entry.first << " :: " << C_entry.second;
    return os;
}
