#ifndef __CHORDCERTTABLE_H_
#define __CHORDCERTTABLE_H_

#include <deque>
#include <map>

#include <omnetpp.h>

#include <NodeVector.h>
#include <InitStages.h>

class BaseOverlay;

namespace oversim {

//typedef std::multimap<simtime_t, NodeHandle> Successors;
//typedef std::pair<NodeHandle, Successors> CertEntry;
typedef std::pair<std::string, OverlayKey> CertEntry;
//typedef std::pair<std::string, OverlayKey> CertEntry;
//typedef std::string CertEntry;
//typedef std::vector<std::string> CertEntry;


class Chord;

/**
 * Chord's cert table module
 *
 * This module contains the node's certificate.
 *
 */
class ChordCertTable : public cSimpleModule
{
  public:

    char *publickey, *cert;

    OverlayKey somaKey;

    //virtual void setCert(const NodeHandle& node);

    virtual int numInitStages() const
    {
        return MAX_STAGE_OVERLAY + 1;
    }

    virtual void initialize(int stage);
    virtual void handleMessage(cMessage* msg);

    /**
     * Sets up the table. Should be called on startup to initialize
     * the table.
     */
    virtual void initializeCertTable(uint32_t size, const NodeHandle& owner, Chord* overlay);


    virtual uint32_t getSize();
    uint32_t maxSize; /**< maximum size of the finger table */
    std::deque<CertEntry> certTable; /**< the cert table vector */
    Chord* overlay; /**< pointer to the main chord module */
};

}; //namespace

//std::ostream& operator<<(std::ostream& os, const oversim::Successors& suc);
std::ostream& operator<<(std::ostream& os, const oversim::CertEntry& C_entry);

#endif
